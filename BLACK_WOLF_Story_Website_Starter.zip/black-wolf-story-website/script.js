const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
menuToggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

document.getElementById('year').textContent = new Date().getFullYear();
const search = document.getElementById('episodeSearch');
const filter = document.getElementById('episodeFilter');
const rows = [...document.querySelectorAll('.episode-row')];
const empty = document.getElementById('emptyState');
function filterEpisodes() {
  const q = search.value.trim().toLowerCase();
  let visible = 0;
  rows.forEach(row => {
    const matchesText = (row.dataset.search + ' ' + row.innerText).toLowerCase().includes(q);
    const matchesStatus = filter.value === 'all' || row.dataset.status === filter.value;
    row.hidden = !(matchesText && matchesStatus);
    if (!row.hidden) visible++;
  });
  empty.hidden = visible !== 0;
}
search.addEventListener('input', filterEpisodes);
filter.addEventListener('change', filterEpisodes);

const dialog = document.getElementById('episodeDialog');
document.querySelectorAll('[data-episode]').forEach(button => {
  button.addEventListener('click', () => {
    if (button.dataset.episode === '1') dialog.showModal();
    else showToast('இந்த episode இன்னும் எழுதப்படவில்லை. விரைவில் சேர்க்கலாம்!');
  });
});
document.getElementById('dialogClose').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => {
  if (event.target === dialog) dialog.close();
});
let toastTimer;
function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}
